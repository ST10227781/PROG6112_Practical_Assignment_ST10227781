/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package studentmanagementapp;

/**
 *
 * @author pc
 */
import java.util.ArrayList;

public class Student {
    private String id;
    private String name;
    private int age;
    private String email;
    private String course;

    // Static list to store all students
    private static ArrayList<Student> students = new ArrayList<>();

    // Constructor
    public Student(String id, String name, int age, String email, String course) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.email = email;
        this.course = course;
    }

    // Getters
    public String getId() { return id; }
    public String getName() { return name; }
    public int getAge() { return age; }
    public String getEmail() { return email; }
    public String getCourse() { return course; }

    // SaveStudent method
    public static void saveStudent(Student student) {
        students.add(student);
        System.out.println("Student details have been successfully saved.");
    }

    // SearchStudent method
    public static Student searchStudent(String id) {
        for (Student student : students) {
            if (student.getId().equals(id)) {
                return student;
            }
        }
        return null;
    }

    // DeleteStudent method
    public static boolean deleteStudent(String id) {
        Student student = searchStudent(id);
        if (student != null) {
            students.remove(student);
            return true;
        }
        return false;
    }

    // StudentReport method
    public static void studentReport() {
        if (students.isEmpty()) {
            System.out.println("No students found.");
        } else {
            System.out.println("STUDENT REPORT");
            System.out.println("****************");
            for (Student student : students) {
                System.out.println("ID: " + student.getId());
                System.out.println("Name: " + student.getName());
                System.out.println("Age: " + student.getAge());
                System.out.println("Email: " + student.getEmail());
                System.out.println("Course: " + student.getCourse());
                System.out.println("****************");
            }
        }
    }

    // ExitStudentApplication method
    public static void exitStudentApplication() {
        System.out.println("Exiting Application...");
        System.exit(0);
    }
}

