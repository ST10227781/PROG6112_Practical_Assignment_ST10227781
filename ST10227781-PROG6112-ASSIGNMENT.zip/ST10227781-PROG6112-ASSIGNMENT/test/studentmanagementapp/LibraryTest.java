/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package studentmanagementapp;

import org.junit.Test;
import static org.junit.Assert.*;

public class LibraryTest {

    @Test
    public void testAddBook() {
        Library library = new Library();
        book book = new book("The Great Gatsby", "F. Scott Fitzgerald", 1925);
        library.addBook(book);

        assertNotNull(library.searchBook("The Great Gatsby"));
    }

    @Test
    public void testSearchBook() {
        Library library = new Library();
        book book = new book("1984", "George Orwell", 1949);
        library.addBook(book);

        book found = library.searchBook("1984");
        assertEquals("1984", found.getTitle());
        assertEquals("George Orwell", found.getAuthor());
    }

    @Test
    public void testDeleteBook() {
        Library library = new Library();
        book book = new book("To Kill a Mockingbird", "Harper Lee", 1960);
        library.addBook(book);

        assertTrue(library.deleteBook("To Kill a Mockingbird"));
        assertNull(library.searchBook("To Kill a Mockingbird"));
    }
}

