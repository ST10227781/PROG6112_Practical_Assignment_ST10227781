/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package studentmanagementapp;

/**
 *
 * @author pc
 */
import java.util.Scanner;

public class LibraryApp {

    public static void main(String[] args) {
        Library library = new Library();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("LIBRARY MANAGEMENT SYSTEM");
            System.out.println("*************************");
            System.out.println("1. Add Book");
            System.out.println("2. Search Book");
            System.out.println("3. Delete Book");
            System.out.println("4. Display All Books");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // consume newline

            switch (choice) {
                case 1:
                    addBook(library, scanner);
                    break;
                case 2:
                    searchBook(library, scanner);
                    break;
                case 3:
                    deleteBook(library, scanner);
                    break;
                case 4:
                    library.displayAllBooks();
                    break;
                case 5:
                    System.out.println("Exiting the application.");
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void addBook(Library library, Scanner scanner) {
        System.out.print("Enter book title: ");
        String title = scanner.nextLine();

        System.out.print("Enter author: ");
        String author = scanner.nextLine();

        System.out.print("Enter publication year: ");
        int year = scanner.nextInt();
        scanner.nextLine(); // consume newline

        System.out.print("Is this an eBook? (yes/no): ");
        String isEBook = scanner.nextLine();

        if (isEBook.equalsIgnoreCase("yes")) {
            System.out.print("Enter format (e.g., PDF, EPUB): ");
            String format = scanner.nextLine();
            EBook ebook = new EBook(title, author, year, format);
            library.addBook(ebook);
        } else {
            book book = new book(title, author, year);
            library.addBook(book);
        }

        System.out.println("Book added successfully!");
    }

    private static void searchBook(Library library, Scanner scanner) {
        System.out.print("Enter the title of the book to search: ");
        String title = scanner.nextLine();
        book book = library.searchBook(title);

        if (book != null) {
            System.out.println("Book found:");
            book.displayInfo();
        } else {
            System.out.println("Book not found.");
        }
    }

    private static void deleteBook(Library library, Scanner scanner) {
        System.out.print("Enter the title of the book to delete: ");
        String title = scanner.nextLine();

        if (library.deleteBook(title)) {
            System.out.println("Book deleted successfully.");
        } else {
            System.out.println("Book not found.");
        }
    }
}

