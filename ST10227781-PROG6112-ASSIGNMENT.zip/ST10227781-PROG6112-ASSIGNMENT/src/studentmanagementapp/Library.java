/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package studentmanagementapp;

/**
 *
 * @author pc
 */
import java.util.ArrayList;

public class Library {
    private ArrayList<book> books;

    // Constructor
    public Library() {
        books = new ArrayList<>();
    }

    // Add a book to the library
    public void addBook(book book) {
        books.add(book);
    }

    // Search for a book by title
    public book searchBook(String title) {
        for (book book : books) {
            if (book.getTitle().equalsIgnoreCase(title)) {
                return book;
            }
        }
        return null;
    }

    // Delete a book by title
    public boolean deleteBook(String title) {
        book book = searchBook(title);
        if (book != null) {
            books.remove(book);
            return true;
        }
        return false;
    }

    // Display all books in the library
    public void displayAllBooks() {
        if (books.isEmpty()) {
            System.out.println("No books in the library.");
        } else {
            for (book book : books) {
                book.displayInfo();
                System.out.println("*************************");
            }
        }
    }
}

