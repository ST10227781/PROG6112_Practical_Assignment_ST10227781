/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package studentmanagementapp;

/**
 *
 * @author pc
 */
public class EBook extends book {
    private String format; // e.g., PDF, EPUB

    // Constructor
    public EBook(String title, String author, int year, String format) {
        super(title, author, year);
        this.format = format;
    }

    // Getters
    public String getFormat() {
        return format;
    }

    @Override
    public void displayInfo() {
        super.displayInfo();
        System.out.println("Format: " + format);
    }
}

