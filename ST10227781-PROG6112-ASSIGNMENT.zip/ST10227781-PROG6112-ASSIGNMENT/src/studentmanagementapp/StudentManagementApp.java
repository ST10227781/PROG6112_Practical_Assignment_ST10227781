/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package studentmanagementapp;

import java.util.ArrayList;
import java.util.Scanner;

public class StudentManagementApp {
    // ArrayList to store student information
    private static ArrayList<Student> students = new ArrayList<>();

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("STUDENT MANAGEMENT APPLICATION");
            System.out.println("*******************************");
            System.out.println("Enter (1) to launch menu or any other key to exit");

            String choice = scanner.nextLine();
            if (choice.equals("1")) {
                displayMenu(scanner);
            } else {
                System.out.println("Exiting Application...");
                break;
            }
        }
        scanner.close();
    }

    private static void displayMenu(Scanner scanner) {
        while (true) {
            System.out.println("Please select one of the following menu items:");
            System.out.println("(1) Capture a new student.");
            System.out.println("(2) Search for a student.");
            System.out.println("(3) Delete a student.");
            System.out.println("(4) Print student report.");
            System.out.println("(5) Exit Application.");

            String choice = scanner.nextLine();
            switch (choice) {
                case "1":
                    captureNewStudent(scanner);
                    break;
                case "2":
                    searchForStudent(scanner);
                    break;
                case "3":
                    deleteStudent(scanner);
                    break;
                case "4":
                    printStudentReport();
                    break;
                case "5":
                    System.out.println("Exiting Application...");
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    private static void captureNewStudent(Scanner scanner) {
        System.out.println("CAPTURE A NEW STUDENT");
        System.out.println("*************************");

        System.out.print("Enter the student id: ");
        String id = scanner.nextLine();

        System.out.print("Enter the student name: ");
        String name = scanner.nextLine();

        int age;
        while (true) {
            System.out.print("Enter the student age: ");
            try {
                age = Integer.parseInt(scanner.nextLine());
                if (age >= 16) break;
                else System.out.println("You have entered an incorrect student age!!!");
            } catch (NumberFormatException e) {
                System.out.println("You have entered an incorrect student age!!!");
            }
        }

        System.out.print("Enter the student email: ");
        String email = scanner.nextLine();

        System.out.print("Enter the student course: ");
        String course = scanner.nextLine();

        // Save the student data
        Student student = new Student(id, name, age, email, course);
        students.add(student);

        System.out.println("Student details have been successfully saved.");
    }

    private static void searchForStudent(Scanner scanner) {
        System.out.print("Enter the student ID to search: ");
        String id = scanner.nextLine();
        boolean found = false;

        for (Student student : students) {
            if (student.getId().equals(id)) {
                System.out.println("Student found:");
                System.out.println("ID: " + student.getId());
                System.out.println("Name: " + student.getName());
                System.out.println("Age: " + student.getAge());
                System.out.println("Email: " + student.getEmail());
                System.out.println("Course: " + student.getCourse());
                found = true;
                break;
            }
        }

        if (!found) {
            System.out.println("Student cannot be located.");
        }
    }

    private static void deleteStudent(Scanner scanner) {
        System.out.print("Enter the student ID to delete: ");
        String id = scanner.nextLine();
        boolean found = false;

        for (Student student : students) {
            if (student.getId().equals(id)) {
                students.remove(student);
                System.out.println("Student with ID " + id + " has been deleted.");
                found = true;
                break;
            }
        }

        if (!found) {
            System.out.println("Student cannot be located.");
        }
    }

    private static void printStudentReport() {
        if (students.isEmpty()) {
            System.out.println("No students found.");
        } else {
            System.out.println("STUDENT REPORT");
            System.out.println("****************");
            for (Student student : students) {
                System.out.println("ID: " + student.getId());
                System.out.println("Name: " + student.getName());
                System.out.println("Age: " + student.getAge());
                System.out.println("Email: " + student.getEmail());
                System.out.println("Course: " + student.getCourse());
                System.out.println("****************");
            }
        }
    }
}

class Student {
    private String id;
    private String name;
    private int age;
    private String email;
    private String course;

    public Student(String id, String name, int age, String email, String course) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.email = email;
        this.course = course;
    }

    public String getId() { return id; }
    public String getName() { return name; }
    public int getAge() { return age; }
    public String getEmail() { return email; }
    public String getCourse() { return course; }
}





